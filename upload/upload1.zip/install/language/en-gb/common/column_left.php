<?php
$_['text_license']       = 'License';
$_['text_installation']  = 'Pre-Installation';
$_['text_configuration'] = 'Configuration';
$_['text_upgrade']       = 'Upgrade';
$_['text_finished']      = 'Finished';
$_['text_language']      = 'Language';